package sk.stuba.fiit.levels;

import sk.stuba.fiit.bomb.HVersionOne;

public class Hard {

	HVersionOne v1 = new HVersionOne();
	
	void init() { 
		
		v1.init();
		
	}	
}

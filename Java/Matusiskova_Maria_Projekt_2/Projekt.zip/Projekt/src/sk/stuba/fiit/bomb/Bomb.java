package sk.stuba.fiit.bomb;

// Interface

public interface Bomb {
	
	public void init();
		
}

package sk.stuba.fiit.levels;

import sk.stuba.fiit.bomb.MVersionOne;

public class Medium {
	
	// association
	MVersionOne v1 = new MVersionOne();
	
	void init() { 
		
		v1.init();
		
	}	
	
}

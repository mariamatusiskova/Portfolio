package sk.stuba.fiit.generalPrints;

public class Print {
	
	// final method to announce incorrect input
	public final void incorrectInput() {
		System.out.println("Something went wrong! Try again:");
	}

}

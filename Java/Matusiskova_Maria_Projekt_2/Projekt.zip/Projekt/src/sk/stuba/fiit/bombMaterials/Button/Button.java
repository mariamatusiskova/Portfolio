package sk.stuba.fiit.bombMaterials.Button;

// an abstract class with abstract methods

public abstract class Button {
	
	public abstract void list();
	
	public abstract void pushButton();
	
	public abstract void checkButton(boolean check);

	public void pushButton(String doubleButtons) {
		// TODO Auto-generated method stub
		
	}
	
	public abstract boolean getPush();
	
	public abstract void setPush(boolean newPush);

	public void pushButton(String doubleButtons, String correctButtons) {
		// TODO Auto-generated method stub
		
	}

}

package sk.stuba.fiit.bombMaterials;

public class Main {
	
	public static void main(String[] args) {
		
		// the user is processing tasks of the bomb to defuse
		User user = new User();	
		user.init();
	}
}
